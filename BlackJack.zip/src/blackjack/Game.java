package blackjack;

import java.util.Random;
import java.util.Scanner;

public class Game 
{
    
   public Player[] players = new Player[4];
   public Card[] deck = new Card[52];
   public int[] highScores = new int[4];

   public void Card_Generator()
   {
       int counter = 0;
       for(int i = 0; i < 4; i++) {
           for(int j = 0; j < 13; j++) {
              int value = ( j >= 10)  ?  10 : j+1;
               Card card = new Card(i, j, value);
               deck[counter] = card;
               counter++;
           }
       }
   }

//    A function that draws a card randomly from the card deck array.
     public Card draw()
   {
       Random random = new Random();
       Card card = null;
       do{
           int randomNum = random.nextInt(51);
           card = deck[randomNum];
           deck[randomNum] = null;
           
       } while (card == null);
     return card;
   }
      
     
//     A function that takes names from the user and draw 2 
//     random cards for each player at the beginning of the game.
     public void set_player_info() 
     {
        
        
           for(int i = 0; i < players.length - 1; i++)
         {
              Scanner scanner = new Scanner(System.in);
              System.out.println("Enter the name of player number " + (i + 1) );
              players[i] = new Player();
              players[i].name = scanner.next();
              players[i].addCard(this.draw());
              players[i].addCard(this.draw());
         }
              players[3] = new Player();
              players[3].name = "dealer";
              players[3].addCard(this.draw());
              players[3].addCard(this.draw());
       }

     
 //    A function that updates the game maximum score of all players after any player draw a card to his hand.
     public void update_score(){
         for (int i = 0; i < highScores.length; i++){
             highScores[i] = players[i].score <= 21 ? players[i].score : 0;
         }     
     }
     
}

