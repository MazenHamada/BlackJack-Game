package blackjack;

import java.util.Scanner;

/**
 *
 * @author Mazen Hamada Badr
 */


public class BlackJack {

   static Game game = new Game();
    
    public static void main(String[] args) {
        
    GUI gui = new GUI();

  game.Card_Generator();
  game.set_player_info();
  
  gui.runGUI( game.deck,   game.players[0].getPlayerHand(),   game.players[1].getPlayerHand(),   game.players[2].getPlayerHand(),   game.players[3].getPlayerHand());
 
  players_turn(gui);
  game.update_score();
  dealer_turn(gui);
  game.update_score();
  check_game_status();
}
    
    public static void players_turn(GUI gui) {
        Scanner scanner =  new Scanner(System.in);
        
        for (int i = 0; i < game.players.length - 1; i++) {
            String input = "";
            while (!input.toLowerCase().equals("stand")){
                System.out.println("player no." + (i +1) + " { Hit or Stand } ");
                input = scanner.next();            
                if (input.toLowerCase().equals("hit")) {
                addCardToPlayer(i, gui);
                }
            }
        }       
    }
    
    public static void addCardToPlayer(int index, GUI gui) {
        Card card = game.draw();
        game.players[index].addCard(card);
        gui.updatePlayerHand(card, index);
    }
    
    public static void dealer_turn(GUI gui) {
        boolean dealerWins = true;
        int highscore = 0;
        for (int i = 0; i < game.players.length - 1; i++){
            if (game.highScores[i] >= game.players[3].score){
                dealerWins = false;
            }
                if (game.highScores[i] > highscore) {
                    highscore = game.highScores[i];
                }
            }
        if (!dealerWins) {
            addCardToDealer(gui, highscore);
        } else {
                    return;
                  }
    }
    
    public static void addCardToDealer(GUI gui, int highscore) {
        
        while (game.players[3].score < highscore) {
                    Card card = game.draw();
                    game.players[3].addCard(card);
                    gui.updateDealerHand(card, game.deck);
        }
    }
    
    public static void check_game_status() {
        int highscore = 0;
        int winner = -1;
        for (int i = 0; i < game.players.length; i++) {
            if (game.highScores[i] > highscore){
                highscore = game.highScores[i];
                winner = i;
            }
        }
        
        if (winner >= 0) {
            System.out.println(" The winner is   " + game.players[winner].name + "  with score : " + highscore);
        }
    }
}

