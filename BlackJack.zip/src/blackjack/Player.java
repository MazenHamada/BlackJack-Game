package blackjack;

public class Player 
{
    public String name;
    public int score = 0;
    private Card[] PlayerHand = new Card[11];
    private int card_counter = 0;
    
    
    
    public void addCard(Card card){
        if (card_counter < 11){
            PlayerHand[card_counter] = card;
            card_counter++;
            score += card.getValue();
        }    
    }

    public Card[] getPlayerHand(){
        return this.PlayerHand;
    }
   
}

